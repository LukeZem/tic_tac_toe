const Header = () => {
  return <h1>React Tac Toe</h1>;
};

export default Header;
