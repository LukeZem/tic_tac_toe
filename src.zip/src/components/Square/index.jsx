const Square = (props) => {
    return (
        <div>
            <h4>square</h4>
        </div>
    )
}

export default Square;